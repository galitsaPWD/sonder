// Admin Dashboard JavaScript
let customerSortConfig = { key: 'id', order: 'asc' };

function initializeSorting() {
    // Customer Table Sorting
    const customerHeaders = {
        'sortAccount': 'id',
        'sortName': 'last_name'
    };

    Object.entries(customerHeaders).forEach(([id, key]) => {
        const el = document.getElementById(id);
        if (el) {
            el.style.cursor = 'pointer';
            el.addEventListener('click', () => {
                if (customerSortConfig.key === key) {
                    customerSortConfig.order = customerSortConfig.order === 'asc' ? 'desc' : 'asc';
                } else {
                    customerSortConfig.key = key;
                    customerSortConfig.order = 'asc';
                }
                updateSortIndicators('customerTable', customerSortConfig);
                refreshCustomers();
            });
        }
    });

    // Initial indicators
    updateSortIndicators('customerTable', customerSortConfig);
}

function updateSortIndicators(tableId, config) {
    const headers = document.querySelectorAll(`#${tableId} .sort-icon`);
    headers.forEach(icon => icon.className = 'fas fa-sort sort-icon');
    
    const activeHeader = document.querySelector(`[data-sort-key="${config.key}"] .sort-icon`);
    if (activeHeader) {
        activeHeader.className = `fas fa-sort-${config.order === 'asc' ? 'up' : 'down'} sort-icon active`;
    }
}

function refreshCustomers() {
    const search = document.getElementById('customerSearch')?.value || '';
    const status = document.getElementById('customerStatusFilter')?.value || '';
    const type = document.getElementById('customerTypeFilter')?.value || '';
    const barangay = document.getElementById('customerBarangayFilter')?.value || '';
    
    if (window.dbOperations && window.dbOperations.loadCustomers) {
        window.dbOperations.loadCustomers({
            search,
            status,
            type,
            barangay,
            sortBy: customerSortConfig.key,
            sortOrder: customerSortConfig.order
        });
    }
}


document.addEventListener('DOMContentLoaded', () => {
    initializeNavigation();
    initializeMobileMenu();
    initializeModals();
    initializeTableActions();
    initializeSearchFilters(); // New
    initializeSettings(); // New
    initializeLogout();
    initializeTheme(); // Added theme support
    initializeSidebarToggle(); // Modern Sidebar Step 3
    
    // Wait a bit for Supabase to initialize, then load data
    setTimeout(() => {
        initializeSorting();
        loadInitialData();
    }, 100);
});

async function loadInitialData() {
    try {
        // Check if Supabase client is ready
        if (!supabase || typeof supabase.from !== 'function') {
            console.error('❌ Supabase client not ready');
            console.log('supabase:', supabase);
            showNotification('Database connection failed. Please refresh the page.', 'error');
            return;
        }
        
        await window.dbOperations.loadDashboardStats();
        refreshCustomers();
        await window.dbOperations.loadStaff();
        await window.dbOperations.loadBilling();
        await window.dbOperations.loadAreaBoxes();
        console.log('Initial data loaded from Supabase');
        
        // Cinematic reveal
        setTimeout(hideLoadingOverlay, 800);
    } catch (error) {
        console.error('Error loading initial data:', error);
        showNotification('Failed to load data from database', 'error');
        // Hide overlay even on error to prevent being stuck
        hideLoadingOverlay();
    }
    
    // ===== SETUP REALTIME SUBSCRIPTIONS =====
    setupRealtimeSubscriptions();
}

function setupRealtimeSubscriptions() {
    if (!window.subscribeToTable) {
        console.warn('[Realtime] subscribeToTable not available');
        return;
    }

    // Subscribe to customers table
    subscribeToTable('customers', () => {
        refreshCustomers();
        if (window.dbOperations && window.dbOperations.loadStats) {
            // Small delay for DELETE to ensure DB is updated
            setTimeout(() => window.dbOperations.loadStats(), 100);
        }
    });

    // Subscribe to staff table
    subscribeToTable('staff', () => {
        if (window.dbOperations && window.dbOperations.loadStaff) {
            window.dbOperations.loadStaff();
        }
        if (window.dbOperations && window.dbOperations.loadStats) {
            // Small delay for DELETE to ensure DB is updated
            setTimeout(() => window.dbOperations.loadStats(), 100);
        }
    });

    // Subscribe to billing table
    subscribeToTable('billing', () => {
        if (window.dbOperations && window.dbOperations.loadBilling) {
            window.dbOperations.loadBilling();
        }
        if (window.dbOperations && window.dbOperations.loadStats) {
            window.dbOperations.loadStats();
        }
    });

    // Subscribe to system_settings table (THE BRAIN!)
    subscribeToTable('system_settings', () => {
        if (window.dbOperations && window.dbOperations.loadSettings) {
            window.dbOperations.loadSettings();
        }
    });
}

function hideLoadingOverlay() {
    const overlay = document.getElementById('loadingOverlay');
    if (overlay) {
        overlay.classList.add('fade-out');
    }
}

// === NAVIGATION ===
function initializeNavigation() {
    const navItems = document.querySelectorAll('.nav-item');
    const pages = document.querySelectorAll('.page');
    const pageTitle = document.getElementById('pageTitle');
    
    navItems.forEach(item => {
        item.addEventListener('click', (e) => {
            e.preventDefault();
            
            // Remove active class from all
            navItems.forEach(nav => nav.classList.remove('active'));
            pages.forEach(page => page.classList.remove('active'));
            
            // Add active class to clicked
            item.classList.add('active');
            
            // Show corresponding page
            const pageName = item.dataset.page;
            const targetPage = document.getElementById(`${pageName}Page`); // Restored line
            
            if (targetPage) {
                targetPage.classList.add('active');
                
                // Close mobile sidebar if open
                if (window.innerWidth <= 1024) {
                    const sidebar = document.getElementById('sidebar');
                    const mobileMenuBtn = document.getElementById('mobileMenuBtn');
                    if (sidebar) sidebar.classList.remove('active');
                    if (mobileMenuBtn) {
                        mobileMenuBtn.innerHTML = '<svg width="24" height="24" viewBox="0 0 24 24" fill="none"><path d="M4 6H20M4 12H20M4 18H20" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>';
                    }
                }
                
                // Load data for specific pages
                if (pageName === 'scheduling') {
                     if (window.dbOperations && window.dbOperations.loadAssignments) {
                        window.dbOperations.loadAssignments();
                     }
                } else if (pageName === 'customers') {
                     refreshCustomers();
                } else if (pageName === 'staff') {
                     window.dbOperations.loadStaff();
                } else if (pageName === 'billing') {
                     window.dbOperations.loadBilling();
                }
            }
            
            // Update page title
            const titles = {
                dashboard: 'Dashboard',
                customers: 'Customer Management',
                staff: 'Staff Management',
                billing: 'Billing Management',
                scheduling: 'Scheduling',
                ledger: 'Master Ledger',
                settings: 'System Settings'
            };
            pageTitle.textContent = titles[pageName] || 'Dashboard';

            if (pageName === 'ledger') {
                initializeLedgerPage();
            }

            if (pageName === 'customers') {
                populateBarangayFilters('customerBarangayFilter');
            }

            if (pageName === 'scheduling') {
                window.dbOperations.loadAreaBoxes();
            }

            if (pageName === 'settings') {
                loadSystemSettingsIntoForm();
            }
        });
    });
}

// === SIDEBAR & MOBILE MENU ===
function initializeMobileMenu() {
    const mobileMenuBtn = document.getElementById('mobileMenuBtn');
    const sidebar = document.getElementById('sidebar');
    
    // Mobile Menu Toggle
    if (mobileMenuBtn) {
        mobileMenuBtn.addEventListener('click', () => {
            sidebar.classList.toggle('active');
        });
    }
    
    // Close sidebar when clicking outside on mobile
    document.addEventListener('click', (e) => {
        if (window.innerWidth <= 1024) {
            if (!sidebar.contains(e.target) && !mobileMenuBtn?.contains(e.target)) {
                sidebar.classList.remove('active');
            }
        }
    });
}

// === MODALS ===
function initializeModals() {
    const addCustomerBtn = document.getElementById('addCustomerBtn');
    const addStaffBtn = document.getElementById('addStaffBtn');
    
    if (addCustomerBtn) {
        addCustomerBtn.addEventListener('click', () => window.showCustomerModal());
    }
    if (addStaffBtn) {
        addStaffBtn.addEventListener('click', () => window.showStaffModal());
    }

    // Scheduling delegation
    document.addEventListener('click', (e) => {
        const addBoxBtn = e.target.closest('#openAddBoxModal');
        if (addBoxBtn) window.showAddBoxModal();
    });
}

function initializeTableActions() {
    console.log('Initializing table actions delegation...');
    // Filter Buttons
    const filterBtns = document.querySelectorAll('.filter-btn');
    filterBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            filterBtns.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            
            // Map data attributes to refreshCustomers logic
            const statusFilter = document.getElementById('customerStatusFilter');
            if (statusFilter) {
                statusFilter.value = btn.dataset.filter === 'all' ? '' : btn.dataset.filter;
                refreshCustomers();
            } else {
                window.dbOperations.loadCustomers(btn.dataset.filter);
            }
        });
    });

    // Event delegation for all table buttons
    document.addEventListener('click', (e) => {
        const editBtn = e.target.closest('.btn-icon[title="Edit"]');
        const deleteBtn = e.target.closest('.btn-icon[title="Delete"]');
        const viewBtn = e.target.closest('.btn-icon[title="View"]'); // Staff/Customer view if any
        const viewBillBtn = e.target.closest('.btn-icon[title="View Bill"]');
        const ledgerBtn = e.target.closest('.btn-icon[title="View Ledger"]');
        
        if (editBtn) {
            console.log('Edit button clicked', editBtn);
            handleEdit(editBtn);
        } else if (deleteBtn) {
            console.log('Delete button clicked', deleteBtn);
            handleDelete(deleteBtn);
        } else if (viewBillBtn) {
            console.log('View Bill button clicked', viewBillBtn);
            handleViewBill(viewBillBtn);
        } else if (ledgerBtn) {
            console.log('Ledger button clicked', ledgerBtn);
            handleViewLedger(ledgerBtn);
        } else if (viewBtn) {
            // Generic view or legacy view
        }
    });
}

// ... existing handleEdit ...
function handleEdit(button) {
    const row = button.closest('tr');
    const customerId = row.dataset.id;
    const cells = row.querySelectorAll('td');
    
    // Determine which table we're in
    const table = button.closest('table');
    const tableBody = table.querySelector('tbody');
    
    if (tableBody.id === 'customerTableBody') {
        window.editCustomer(customerId, row, cells);
    } else if (tableBody.id === 'staffTableBody') {
        window.editStaff(customerId, row, cells);
    }
}

function handleDelete(button) {
    const row = button.closest('tr');
    const id = row.dataset.id;
    const cells = row.querySelectorAll('td');
    const name = cells[1].textContent;
    
    // Determine which table we're in
    const table = button.closest('table');
    const tableBody = table.querySelector('tbody');
    
    let itemType = 'item';
    let deleteFunction = null;
    
    if (tableBody.id === 'customerTableBody') {
        itemType = 'customer';
        deleteFunction = window.dbOperations.deleteCustomer;
    } else if (tableBody.id === 'staffTableBody') {
        itemType = 'staff member';
        deleteFunction = window.dbOperations.deleteStaff;
    }
    
    window.showConfirmModal({
        title: `Delete ${itemType}?`,
        message: `Are you sure you want to delete "${name}"? This action cannot be undone.`,
        confirmText: 'Delete Forever',
        onConfirm: async () => {
            // Animate row removal
            row.style.transition = 'all 0.3s ease';
            row.style.opacity = '0';
            row.style.transform = 'translateY(10px)';
            
            setTimeout(async () => {
                try {
                    await deleteFunction(id);
                } catch (error) {
                    console.error(`Failed to delete ${itemType}:`, error);
                    row.style.opacity = '1';
                    row.style.transform = 'translateX(0)';
                    window.showNotification(`Failed to delete ${itemType}`, 'error');
                }
            }, 300);
        }
    });
}

function handleViewBill(button) {
    const row = button.closest('tr');
    // We need to fetch the full data because the table doesn't show everything (tax, penalty, etc.)
    // But since we don't have a "getBillById" function yet, we can either extract from row (incomplete) 
    // or fetch. For speed, let's extract what we can and assume default for others or use a data-object.
    // Better approach: The row should ideally store the full object in a data attribute, or we fetch.
    // Let's implement a quick fetch by ID or just assume we have the data in the row's scope if we saved it.
    // Since we didn't save it, let's fetch it using the ID.
    const billId = row.dataset.id;
    showBillModal(billId);
}

// Table action handlers moved to initializeTableActions

async function handleViewLedger(button) {
    const row = button.closest('tr');
    // We need customer_id. The row has bill ID mostly.
    // But wait, the row in the table (loadBilling) was generated with:
    // data-id="${bill.id}". It doesn't have customer_id directly.
    // We should fix loadBilling to include data-customer-id on the row.
    // OR we fetch the bill first to get the customer_id. Fetching is safer.
    const billId = row.dataset.id;
    
    try {
        // 1. Get customer ID from the bill ID
        const { data: bill, error: billError } = await supabase
            .from('billing')
            .select('customer_id, customers(last_name, first_name, middle_initial)')
            .eq('id', billId)
            .maybeSingle();
            
        if (billError) throw billError;
        if (!bill) throw new Error('Bill record not found');
        if (!bill.customers) throw new Error('Customer linked to this bill not found');
        
        const customerId = bill.customer_id;
        const middleInitial = bill.customers.middle_initial ? ` ${bill.customers.middle_initial}.` : '';
        const customerName = `${bill.customers.last_name}, ${bill.customers.first_name}${middleInitial}`;
        
        // 2. Load history
        const history = await window.dbOperations.loadCustomerBillingHistory(customerId);
        
        const modalHTML = `
            <div class="modal-overlay" id="ledgerModal">
                <div class="modal" style="max-width: 800px;">
                    <div class="modal-header">
                        <h3>Billing Ledger - ${customerName}</h3>
                        <button class="modal-close" onclick="closeModal('ledgerModal')">
                            <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                                <path d="M5 5L15 15M5 15L15 5" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                            </svg>
                        </button>
                    </div>
                    <div class="modal-form">
                        <div class="ledger-summary">
                            <div class="stat-box">
                                <span class="label">Balance</span>
                                <span class="value">₱${history.reduce((sum, b) => sum + b.balance, 0).toLocaleString()}</span>
                            </div>
                            <div class="stat-box">
                                <span class="label">Total Paid</span>
                                <span class="value">₱${history.filter(b => b.status === 'paid').reduce((sum, b) => sum + b.amount, 0).toLocaleString()}</span>
                            </div>
                        </div>
                        
                        <div class="table-container" style="max-height: 400px; overflow-y: auto; margin-top: 1rem;">
                            <table class="data-table">
                                <thead>
                                    <tr>
                                        <th>Date</th>
                                        <th>Period</th>
                                        <th>Ref No.</th>
                                        <th>Charges</th>
                                        <th>Payments</th>
                                        <th>Balance</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    ${history.map(item => `
                                    <tr>
                                        <td>${new Date(item.created_at).toLocaleDateString()}</td>
                                        <td>${item.billing_period}</td>
                                        <td>BIL-${String(item.id).padStart(4,'0')}</td>
                                        <td>₱${item.amount.toLocaleString()}</td>
                                        <td>${item.status === 'paid' ? '₱' + item.amount.toLocaleString() : '-'}</td>
                                        <td>₱${item.balance.toLocaleString()}</td>
                                        <td><span class="badge ${item.status === 'paid' ? 'success' : (item.status === 'overdue' ? 'danger' : 'warning')}">${item.status}</span></td>
                                    </tr>
                                    `).join('')}
                                </tbody>
                            </table>
                        </div>
                        
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" onclick="closeModal('ledgerModal')">Close</button>
                        </div>
                    </div>
                </div>
            </div>
        `;
        document.getElementById('modalContainer').innerHTML = modalHTML;
        
    } catch (error) {
        console.error('Error loading ledger:', error);
        showNotification('Failed to load ledger', 'error');
    }
}

// Update User Info from Database
async function updateUserInfo() {
    try {
        const { data: { session } } = await supabase.auth.getSession();
        if (!session || !session.user) return;

        // Fetch from profiles table for the actual name
        const { data: profile, error } = await supabase
            .from('profiles')
            .select('*')
            .eq('id', session.user.id)
            .single();

        if (error || !profile) {
            console.error('Failed to load profile for admin:', error);
            // Fallback to email if profile missing
            const email = session.user.email;
            const namePart = email.split('@')[0];
            const displayName = namePart.charAt(0).toUpperCase() + namePart.slice(1);
            
            const userNameEl = document.querySelector('.user-name');
            const avatarEl = document.querySelector('.user-avatar');
            
            if (userNameEl) userNameEl.textContent = displayName;
            if (avatarEl) avatarEl.textContent = displayName.charAt(0);
            return;
        }

        const displayName = `${profile.first_name} ${profile.last_name}`;
        const userNameEl = document.querySelector('.user-name');
        const avatarEl = document.querySelector('.user-avatar');
        
        if (userNameEl) userNameEl.textContent = displayName;
        if (avatarEl) avatarEl.textContent = profile.first_name.charAt(0).toUpperCase();
        
        console.log('Admin UI updated with real profile:', displayName);
    } catch (err) {
        console.error('Error updating admin info:', err);
    }
}

updateUserInfo();

console.log('Admin dashboard initialized');

// === AUTO ASSIGN BUTTONS ===
function initializeAutoAssign() {
    // Auto-Fill (Optional Action)
    const autoBtn = document.getElementById('autoDistributeBtn');
    if (autoBtn) {
        autoBtn.addEventListener('click', async () => {
            if (confirm('Randomly distribute readers to all areas? This will overwrite existing assignments.')) {
                // Pass true = Auto-Distribute
                if (window.dbOperations && window.dbOperations.autoAssignReaders) {
                    await window.dbOperations.autoAssignReaders(true);
                }
            }
        });
    }
}
// === SYSTEM SETTINGS ===
function initializeSettings() {
    const saveBtn = document.getElementById('saveSettingsBtn');
    const changePINBtn = document.getElementById('changePINBtn');

    if (saveBtn) {
        saveBtn.addEventListener('click', async () => {
            if (!window.currentSettings) {
                showNotification('Settings not loaded. Attempting to refresh...', 'info');
                await loadSystemSettingsIntoForm();
                if (!window.currentSettings) return;
            }

            // Security gate before saving settings
            showPINVerifyModal(async () => {
                await saveSettingsChanges();
            });
        });
    }

    if (changePINBtn) {
        changePINBtn.addEventListener('click', () => {
            showChangePINModal();
        });
    }
}

window.showPINVerifyModal = function(onConfirm) {
    const modalHTML = `
        <div class="modal-overlay" id="verifyPINModal">
            <div class="modal pin-verify-modal">
                <div class="modal-body" style="padding: 0;">
                    <div class="pin-verify-header">
                        <div class="pin-verify-icon">
                            <i class="fas fa-lock"></i>
                        </div>
                        <h3 class="no-margin">Access Verification</h3>
                        <p class="pin-verify-text">Enter System PIN to continue</p>
                    </div>
                    
                    <form id="verifyPINForm" class="pin-verify-form">
                        <div class="form-group">
                            <input type="password" id="verifyPINInput" class="form-control pin-input-field" 
                                    inputmode="numeric" pattern="[0-9]*" autocomplete="off"
                                    placeholder="••••" required maxlength="6" />
                        </div>
                        
                        <div class="modal-footer-flex">
                            <button type="button" class="btn btn-secondary flex-1" onclick="closeModal('verifyPINModal')">Cancel</button>
                            <button type="submit" class="btn btn-primary flex-1">Verify PIN</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    `;

    document.getElementById('modalContainer').innerHTML = modalHTML;
    const input = document.getElementById('verifyPINInput');
    input.focus();

    document.getElementById('verifyPINForm').addEventListener('submit', async (e) => {
        e.preventDefault();
        const btn = e.target.querySelector('button[type="submit"]');
        const originalText = btn.innerHTML;
        
        btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
        btn.disabled = true;

        const isVerified = await window.dbOperations.verifyAdminPIN(input.value);
        
        if (isVerified) {
            closeModal('verifyPINModal');
            onConfirm();
        } else {
            btn.innerHTML = originalText;
            btn.disabled = false;
            showNotification('Incorrect PIN. Access Denied.', 'error');
            
            // Shake effect
            const modal = document.querySelector('#verifyPINModal .modal');
            modal.style.animation = 'none';
            void modal.offsetWidth; // trigger reflow
            modal.style.animation = 'shake 0.4s cubic-bezier(.36,.07,.19,.97) both';
            input.value = '';
            input.focus();
        }
    });
};

window.showChangePINModal = function() {
    const modalHTML = `
        <div class="modal-overlay" id="changePINModal">
            <div class="modal small-modal">
                <div class="modal-header">
                    <h3>Update System PIN</h3>
                    <button class="modal-close" onclick="closeModal('changePINModal')">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                
                <form class="modal-form" id="changePINForm">
                    <div class="form-group">
                        <label>Current PIN</label>
                        <input type="password" id="currentPIN" class="form-control" required maxlength="6" inputmode="numeric" pattern="[0-9]*" placeholder="••••" />
                    </div>
                    <div class="form-group divider-top">
                        <label>New PIN (4-6 digits)</label>
                        <input type="password" id="newPIN" class="form-control" required maxlength="6" inputmode="numeric" pattern="[0-9]*" placeholder="••••" />
                    </div>
                    <div class="form-group">
                        <label>Confirm New PIN</label>
                        <input type="password" id="confirmPIN" class="form-control" required maxlength="6" inputmode="numeric" pattern="[0-9]*" placeholder="••••" />
                    </div>
                    
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" onclick="closeModal('changePINModal')">Cancel</button>
                        <button type="submit" class="btn btn-primary">Update PIN</button>
                    </div>
                </form>
            </div>
        </div>
    `;

    document.getElementById('modalContainer').innerHTML = modalHTML;

    document.getElementById('changePINForm').addEventListener('submit', async (e) => {
        e.preventDefault();
        const currentPIN = document.getElementById('currentPIN').value;
        const newPIN = document.getElementById('newPIN').value;
        const confirmPIN = document.getElementById('confirmPIN').value;

        if (newPIN.length < 4 || newPIN.length > 6) {
            showNotification('New PIN must be 4 to 6 digits.', 'error');
            return;
        }

        if (newPIN !== confirmPIN) {
            showNotification('New PINs do not match.', 'error');
            return;
        }

        // Direct update with internal verification
        const btn = e.target.querySelector('button[type="submit"]');
        const originalText = btn.innerHTML;
        btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Updating...';
        btn.disabled = true;

        try {
            const success = await window.dbOperations.updateAdminPIN(newPIN, currentPIN);
            if (success) {
                showNotification('System PIN updated successfully', 'success');
                closeModal('changePINModal');
                await loadSystemSettingsIntoForm();
            } else {
                btn.innerHTML = originalText;
                btn.disabled = false;
            }
        } catch (error) {
            console.error('Failed to update PIN:', error);
            btn.innerHTML = originalText;
            btn.disabled = false;
        }
    });
};

async function loadSystemSettingsIntoForm() {
    try {
        if (!window.dbOperations || !window.dbOperations.loadSystemSettings) return;
        
        const saveBtn = document.getElementById('saveSettingsBtn');
        if (saveBtn) saveBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Loading...';
        
        window.currentSettings = await window.dbOperations.loadSystemSettings();
        
        if (window.currentSettings) {
            document.getElementById('base_rate').value = window.currentSettings.base_rate || 0;
            document.getElementById('tier1_threshold').value = window.currentSettings.tier1_threshold || 0;
            document.getElementById('tier1_rate').value = window.currentSettings.tier1_rate || 0;
            document.getElementById('tier2_threshold').value = window.currentSettings.tier2_threshold || 0;
            document.getElementById('tier2_rate').value = window.currentSettings.tier2_rate || 0;
            document.getElementById('tier3_rate').value = window.currentSettings.tier3_rate || 0;
            document.getElementById('settingDiscount').value = window.currentSettings.discount_percentage;
            document.getElementById('settingPenalty').value = window.currentSettings.penalty_percentage || 10;
            document.getElementById('settingCutoff').value = window.currentSettings.cutoff_days;
        }

        if (saveBtn) {
            saveBtn.innerHTML = '<i class="fas fa-save"></i> Save Settings';
            saveBtn.classList.remove('btn-danger');
            saveBtn.classList.add('btn-primary');
        }
    } catch (error) {
        console.error('Error loading settings into form:', error);
        const saveBtn = document.getElementById('saveSettingsBtn');
        if (saveBtn) {
            saveBtn.innerHTML = '<i class="fas fa-exclamation-triangle"></i> Retry Load';
            saveBtn.classList.remove('btn-primary');
            saveBtn.classList.add('btn-danger');
        }
    }
}

async function saveSettingsChanges() {
    try {
        const updatedData = {
            id: window.currentSettings.id,
            base_rate: parseFloat(document.getElementById('base_rate').value),
            tier1_threshold: parseInt(document.getElementById('tier1_threshold').value),
            tier1_rate: parseFloat(document.getElementById('tier1_rate').value),
            tier2_threshold: parseInt(document.getElementById('tier2_threshold').value),
            tier2_rate: parseFloat(document.getElementById('tier2_rate').value),
            tier3_rate: parseFloat(document.getElementById('tier3_rate').value),
            discount_percentage: parseFloat(document.getElementById('settingDiscount').value),
            penalty_percentage: parseFloat(document.getElementById('settingPenalty').value),
            cutoff_days: parseInt(document.getElementById('settingCutoff').value),
        };

        await window.dbOperations.updateSystemSettings(updatedData);
        window.currentSettings = updatedData;
        showNotification('Settings saved successfully', 'success');
        
        loadSystemSettingsIntoForm(); // Refresh
    } catch (error) {
        console.error('Error saving settings:', error);
        showNotification('Failed to save settings', 'error');
    }
}

// === SEARCH & FILTERS ===
function initializeSearchFilters() {
    console.log('Initializing search filters...');
    const customerSearch = document.getElementById('customerSearch');
    const customerStatus = document.getElementById('customerStatusFilter');
    const customerType = document.getElementById('customerTypeFilter');
    const customerBarangay = document.getElementById('customerBarangayFilter');
    
    const staffSearch = document.getElementById('staffSearch');
    const staffStatus = document.getElementById('staffStatusFilter');
    const staffRole = document.getElementById('staffRoleFilter');

    const billingSearch = document.getElementById('billingSearch');
    const billingStatus = document.getElementById('billingStatusFilter');
    const billingMonth = document.getElementById('billingMonthFilter');

    // Customer Filters
    const updateCustomerFilters = () => {
        window.dbOperations.loadCustomers({
            search: customerSearch?.value || '',
            status: customerStatus?.value || '',
            type: customerType?.value || '',
            barangay: customerBarangay?.value || ''
        });
    };

    if (customerSearch) customerSearch.addEventListener('input', updateCustomerFilters);
    if (customerStatus) customerStatus.addEventListener('change', updateCustomerFilters);
    if (customerType) customerType.addEventListener('change', updateCustomerFilters);
    if (customerBarangay) customerBarangay.addEventListener('change', updateCustomerFilters);

    // Staff Filters
    const updateStaffFilters = () => {
        window.dbOperations.loadStaff({
            search: staffSearch?.value || '',
            status: staffStatus?.value || '',
            role: staffRole?.value || ''
        });
    };

    if (staffSearch) staffSearch.addEventListener('input', updateStaffFilters);
    if (staffStatus) staffStatus.addEventListener('change', updateStaffFilters);
    if (staffRole) staffRole.addEventListener('change', updateStaffFilters);

    // Billing Filters
    const updateBillingFilters = () => {
        window.dbOperations.loadBilling({
            search: billingSearch?.value || '',
            status: billingStatus?.value || '',
            month: billingMonth?.value || ''
        });
    };

    if (billingSearch) billingSearch.addEventListener('input', updateBillingFilters);
    if (billingStatus) billingStatus.addEventListener('change', updateBillingFilters);
    if (billingMonth) billingMonth.addEventListener('change', updateBillingFilters);
}

// === LOGOUT ===
function initializeLogout() {
    const logoutBtn = document.getElementById('logoutBtn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', async () => {
            if (confirm('Are you sure you want to sign out?')) {
                try {
                    const { error } = await supabase.auth.signOut();
                    if (error) throw error;
                    window.location.href = '../index.html';
                } catch (error) {
                    console.error('Error signing out:', error);
                    alert('Error signing out. Please try again.');
                }
            }
        });
    }
}

// === THEME MANAGEMENT ===
function initializeTheme() {
    const themeToggle = document.getElementById('themeToggle');
    const savedTheme = localStorage.getItem('admin-theme') || 'light';
    
    // Apply saved theme
    if (savedTheme === 'dark') {
        document.body.classList.add('dark-theme');
        if (themeToggle) {
            themeToggle.innerHTML = '<i class="fas fa-sun"></i>';
            themeToggle.style.color = '#FFD700'; // Gold Sun
        }
    }
    
    if (themeToggle) {
        themeToggle.addEventListener('click', toggleTheme);
    }
}

function toggleTheme() {
    const themeToggle = document.getElementById('themeToggle');
    const isDark = document.body.classList.toggle('dark-theme');
    
    // Update icon and save preference
    if (isDark) {
        localStorage.setItem('admin-theme', 'dark');
        if (themeToggle) {
            themeToggle.innerHTML = '<i class="fas fa-sun"></i>';
            themeToggle.style.color = '#FFD700'; // Gold Sun
        }
    } else {
        localStorage.setItem('admin-theme', 'light');
        if (themeToggle) {
            themeToggle.innerHTML = '<i class="fas fa-moon"></i>';
            themeToggle.style.color = '#0288D1'; // Original Blue Moon
        }
    }
}

// === CHART MANAGEMENT ===
let consumptionChart = null;
let paymentStatusChart = null;

function updateDashboardCharts(data) {
    // Update Stat Totals in Pesos
    const statUnpaidAmount = document.getElementById('statUnpaidAmount');
    const statOverdueAmount = document.getElementById('statOverdueAmount');
    if (statUnpaidAmount) statUnpaidAmount.textContent = `₱${(data.status.unpaidAmount || 0).toLocaleString(undefined, { minimumFractionDigits: 2 })}`;
    if (statOverdueAmount) statOverdueAmount.textContent = `₱${(data.status.overdueAmount || 0).toLocaleString(undefined, { minimumFractionDigits: 2 })}`;

    // 1. Update Consumption Line Chart
    const ctxConsumption = document.getElementById('consumptionChart')?.getContext('2d');
    if (ctxConsumption) {
        if (consumptionChart) {
            consumptionChart.data.labels = data.consumption.labels;
            consumptionChart.data.datasets[0].data = data.consumption.values;
            consumptionChart.update();
        } else {
            consumptionChart = new Chart(ctxConsumption, {
                type: 'line',
                data: {
                    labels: data.consumption.labels,
                    datasets: [{
                        label: 'Consumption (m³)',
                        data: data.consumption.values,
                        borderColor: '#0288D1',
                        backgroundColor: 'rgba(2, 136, 209, 0.1)',
                        borderWidth: 3,
                        tension: 0.4,
                        fill: true,
                        pointBackgroundColor: '#0288D1',
                        pointBorderColor: '#fff',
                        pointHoverRadius: 6
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: { display: false }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            title: { display: true, text: 'Consumption (m³)', font: { family: 'Inter', size: 11, weight: '600' }, color: '#64748B' },
                            grid: { color: 'rgba(148, 163, 184, 0.05)' },
                            ticks: { font: { family: 'Inter', size: 11 }, color: '#64748B' }
                        },
                        x: {
                            grid: { display: false },
                            ticks: { font: { family: 'Inter', size: 11 }, color: '#64748B', padding: 10 }
                        }
                    }
                }
            });
        }
    }

    // 2. Update Payment Status Pie Chart
    const ctxPayment = document.getElementById('paymentStatusChart')?.getContext('2d');
    if (ctxPayment) {
        const statusValues = [data.status.paid, data.status.unpaid, data.status.overdue];
        const total = statusValues.reduce((a, b) => a + b, 0);
        
        if (paymentStatusChart) {
            paymentStatusChart.data.datasets[0].data = statusValues;
            paymentStatusChart.options.plugins.centerText.text = total.toString();
            paymentStatusChart.update();
        } else {
            // Register a custom plugin for the center text
            const centerTextPlugin = {
                id: 'centerText',
                text: total.toString(),
                afterDraw: (chart) => {
                    const { ctx, chartArea: { top, bottom, left, right, width, height } } = chart;
                    ctx.save();
                    
                    // Draw "TOTAL" label
                    ctx.font = '500 12px Inter';
                    ctx.fillStyle = '#64748B';
                    ctx.textAlign = 'center';
                    ctx.textBaseline = 'middle';
                    ctx.fillText('TOTAL BILLS', width / 2, height / 2 - 15 + top);
                    
                    // Draw the count
                    ctx.font = 'bold 36px Inter';
                    ctx.fillStyle = document.body.classList.contains('dark-theme') ? '#F9FAFB' : '#1E293B';
                    ctx.fillText(chart.config.options.plugins.centerText.text, width / 2, height / 2 + 18 + top);
                    
                    ctx.restore();
                }
            };

            paymentStatusChart = new Chart(ctxPayment, {
                type: 'doughnut',
                plugins: [centerTextPlugin],
                data: {
                    labels: ['Paid', 'Unpaid', 'Overdue'],
                    datasets: [{
                        data: statusValues,
                        backgroundColor: [
                            '#10B981', // Emerald 500
                            '#F59E0B', // Amber 500
                            '#EF4444'  // Red 500
                        ],
                        hoverBackgroundColor: [
                            '#059669', // Emerald 600
                            '#D97706', // Amber 600
                            '#DC2626'  // Red 600
                        ],
                        borderWidth: 0,
                        hoverOffset: 15,
                        borderRadius: 4,
                        spacing: 2
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'bottom',
                            labels: {
                                padding: 25,
                                usePointStyle: true,
                                pointStyle: 'circle',
                                font: {
                                    family: 'Inter',
                                    size: 13,
                                    weight: '500'
                                },
                                color: '#64748B'
                            }
                        },
                        tooltip: {
                            backgroundColor: 'rgba(30, 41, 59, 0.9)',
                            padding: 12,
                            titleFont: { size: 14, weight: 'bold' },
                            bodyFont: { size: 13 },
                            cornerRadius: 8,
                            displayColors: true
                        },
                        centerText: {
                            text: total.toString()
                        }
                    },
                    cutout: '80%',
                    animation: {
                        animateScale: true,
                        animateRotate: true
                    }
                }
            });
        }
    }
}

// Expose to window for database operations access
window.updateDashboardCharts = updateDashboardCharts;
// === MASTER LEDGER LOGIC ===

function initializeLedgerPage() {
    const barangayFilter = document.getElementById('ledgerBarangayFilter');
    const searchInput = document.getElementById('ledgerSearch');
    const backBtn = document.getElementById('backToMasterBtnDetail');

    // Populate Barangays if not already
    populateBarangayFilters('ledgerBarangayFilter');

    // Event Listeners
    const updateLedger = () => {
        window.dbOperations.loadMasterLedger({
            barangay: barangayFilter.value,
            search: searchInput.value
        });
    };

    barangayFilter?.addEventListener('change', updateLedger);
    searchInput?.addEventListener('input', debounce(updateLedger, 300));

    // Print Logic
    document.getElementById('printLedgerBtn').onclick = () => {
        const printDate = document.querySelector('.print-date');
        if (printDate) {
            printDate.textContent = `Generated on: ${new Date().toLocaleString()}`;
        }
        window.print();
    };

    // Detail View Controls
    const closeDetail = () => {
        document.getElementById('ledgerMasterView').style.display = 'block';
        document.getElementById('ledgerDetailView').style.display = 'none';
        document.querySelector('.ledger-controls').style.display = 'block';
        document.getElementById('backToMasterBtn').style.display = 'none';
        document.getElementById('printLedgerBtn').innerHTML = '<i class="fas fa-print"></i> Print Report';
    };

    if (backBtn) backBtn.onclick = closeDetail;
    document.getElementById('backToMasterBtn').onclick = closeDetail;

    // Initial Load
    document.getElementById('ledgerMasterView').style.display = 'block';
    document.getElementById('ledgerDetailView').style.display = 'none';
    updateLedger();
}


/**
 * Global function to switch to individual customer ledger card
 */
window.viewCustomerLedger = async function(customerId) {
    // Switch views
    document.getElementById('ledgerMasterView').style.display = 'none';
    document.getElementById('ledgerDetailView').style.display = 'block';
    
    // Hide master filters
    document.querySelector('.ledger-controls').style.display = 'none';
    
    // Show back button and update Print Button
    document.getElementById('backToMasterBtn').style.display = 'inline-block';
    document.getElementById('printLedgerBtn').innerHTML = '<i class="fas fa-print"></i> Print Customer Card';
    
    // Load data
    await window.dbOperations.loadLedgerCard(customerId);
};

// Simple debounce
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}
/**
 * Utility to populate any barangay select element
 */
function populateBarangayFilters(selectId) {
    const filter = document.getElementById(selectId);
    if (!filter || filter.options.length > 1) return;

    const barangays = window.dbOperations ? 
        (window.dbOperations.PULUPANDAN_BARANGAYS || []) : 
        (window.PULUPANDAN_BARANGAYS || []);
        
    barangays.forEach(bg => {
        const opt = document.createElement('option');
        opt.value = bg;
        opt.textContent = bg;
        filter.appendChild(opt);
    });
}

/**
 * Modern Sidebar Persistence & Toggle Logic
 */
function initializeSidebarToggle() {
    const sidebar = document.getElementById('sidebar');
    const toggleBtn = document.getElementById('sidebarToggle');
    
    if (!sidebar || !toggleBtn) return;

    // 1. Load preference from localStorage
    const sidebarPinnedMini = localStorage.getItem('sidebar-pinned-mini') === 'true';
    
    // 2. Apply initial state
    if (sidebarPinnedMini) {
        sidebar.classList.add('mini');
    } else {
        sidebar.classList.remove('mini');
    }

    // 3. Handle Toggle Click
    toggleBtn.addEventListener('click', () => {
        sidebar.classList.toggle('mini');
        
        // Save preference
        const isMini = sidebar.classList.contains('mini');
        localStorage.setItem('sidebar-pinned-mini', isMini);
    });
}

function initializeSidebarToggle() {
    const sidebar = document.getElementById('sidebar');
    const toggleBtn = document.getElementById('sidebarToggle');
    
    if (toggleBtn && sidebar && window.innerWidth > 1024) {
        // Load preference
        const isMini = localStorage.getItem('sidebar-mini') === 'true';
        if (isMini) {
            sidebar.classList.add('mini');
        }

        toggleBtn.addEventListener('click', () => {
            sidebar.classList.add('is-animating'); // Lock tooltips
            sidebar.classList.toggle('mini');
            
            // Remove lock after transition
            setTimeout(() => {
                sidebar.classList.remove('is-animating');
            }, 400);

            localStorage.setItem('sidebar-mini', sidebar.classList.contains('mini'));
        });
    }
}

