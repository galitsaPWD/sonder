// Auth Guard for Protected Pages
(async function() {
    // Wait for Supabase to be initialized if needed
    // But since it's loaded before this in dashboard.html, it should be fine
    
    function checkSession() {
        if (!window.supabase) {
            console.error('Supabase client not found');
            return;
        }

        supabase.auth.getSession().then(({ data: { session } }) => {
            if (!session) {
                console.log('No active session. Redirecting to login...');
                window.location.href = '../index.html';
            } else {
                console.log('Session active:', session.user.email);
                // Expose user to the window if needed
                window.authUser = session.user;
            }
        });

        // Also listen for auth changes
        supabase.auth.onAuthStateChange((event, session) => {
            if (event === 'SIGNED_OUT' || !session) {
                window.location.href = '../index.html';
            }
        });
    }

    // Run check
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', checkSession);
    } else {
        checkSession();
    }
})();
