// Secure Cashier Authentication (Supabase Auth)
// Replaces insecure sessionStorage

async function checkStaffAuth() {
    try {
        // 1. Get Supabase Session
        const { data: { session }, error } = await supabase.auth.getSession();
        
        if (error || !session) {
            console.warn('No active session found. Redirecting...');
            window.location.href = '../index.html';
            return null;
        }

        const user = session.user;

        // 2. Initial "Quick Check" (from Metadata/Session if available, else DB)
        // For security, we always double-check the Role against the DB "profiles" table.
        const { data: profile, error: profileError } = await supabase
            .from('profiles')
            .select('*')
            .eq('id', user.id)
            .single();

        if (profileError || !profile) {
            console.error('Profile not found for user:', user.id);
            await supabase.auth.signOut();
            window.location.href = '../index.html';
            return null;
        }

        // 3. Role Enforcement
        // Only 'cashier' allowed here. Admins have their own dashboard.
        if (profile.role !== 'cashier') {
            console.error('Unauthorized Access: User is not a cashier. Current Role:', profile.role);
            
            // If they are an admin, redirect them to the admin dashboard
            if (profile.role === 'admin') {
                window.location.href = '../admin/dashboard.html';
            } else {
                alert('Access Denied. Cashiers only.');
                await supabase.auth.signOut();
                window.location.href = '../index.html';
            }
            return null;
        }

        return profile;

    } catch (err) {
        console.error('Auth Check Failed:', err);
        window.location.href = '../index.html';
        return null;
    }
}

// Global Logout
async function staffLogout() {
    const { error } = await supabase.auth.signOut();
    if (error) console.error('Logout failed:', error);
    window.location.href = '../index.html';
}

// Expose to window
window.checkStaffAuth = checkStaffAuth;
window.staffLogout = staffLogout;

// Auto-run on load
document.addEventListener('DOMContentLoaded', () => {
    checkStaffAuth();
});
