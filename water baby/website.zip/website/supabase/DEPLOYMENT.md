# Edge Function Deployment Guide

## Quick Setup (5 minutes)

### Step 1: Install Supabase CLI

```powershell
# Install via npm
npm install -g supabase
```

### Step 2: Login to Supabase

```powershell
supabase login
```

This will open your browser. Authorize the CLI.

### Step 3: Link Your Project

```powershell
cd "c:\Users\Dell\OneDrive\Desktop\Projects\portfolio\water baby\website"
supabase link --project-ref YOUR_PROJECT_REF
```

**To find YOUR_PROJECT_REF:**

1. Go to Supabase Dashboard
2. Look at the URL: `https://supabase.com/dashboard/project/YOUR_PROJECT_REF`
3. Copy that ID

### Step 4: Deploy the Function

```powershell
supabase functions deploy create-user
```

### Step 5: Test It

After deployment, you'll get a URL like:

```
https://YOUR_PROJECT_REF.supabase.co/functions/v1/create-user
```

Test with:

```powershell
curl -X POST https://YOUR_PROJECT_REF.supabase.co/functions/v1/create-user `
  -H "Authorization: Bearer YOUR_ANON_KEY" `
  -H "Content-Type: application/json" `
  -d '{\"email\":\"test@example.com\",\"password\":\"test123\",\"role\":\"cashier\",\"firstName\":\"Test\",\"lastName\":\"User\"}'
```

## Troubleshooting

**Error: "supabase command not found"**

- Restart your terminal after installing
- Or use: `npx supabase` instead of `supabase`

**Error: "Project not linked"**

- Make sure you're in the correct directory
- Run `supabase link` again with correct project ref

**Error: "Unauthorized"**

- Check your ANON key in the request
- Get it from: Supabase Dashboard → Settings → API

## Next Step

Once deployed, the Admin dashboard will automatically use this function when you click "Add Staff"!
