# Quick Deployment (Updated - Use npx)

## Step 1: Login to Supabase

```powershell
npx supabase login
```

This will open your browser - authorize the CLI.

## Step 2: Get Your Project Reference

1. Go to your Supabase Dashboard
2. Look at the URL: `https://supabase.com/dashboard/project/YOUR_PROJECT_REF`
3. Copy that ID (it's also in Settings → General → Reference ID)

## Step 3: Link Your Project

```powershell
cd "c:\Users\Dell\OneDrive\Desktop\Projects\portfolio\water baby\website"
npx supabase link --project-ref YOUR_PROJECT_REF
```

## Step 4: Deploy the Function

```powershell
npx supabase functions deploy create-user
```

## Step 5: Done!

Go to Admin Dashboard → Staff Management → Click "Add Staff" and test it!

---

## Troubleshooting

**"Need to provide a project ref"**

- Make sure you replaced `YOUR_PROJECT_REF` with your actual project ID

**"Function not found" when testing**

- Wait 30 seconds after deployment
- Check Supabase Dashboard → Edge Functions to verify it deployed

**"Unauthorized" error**

- The function uses your service_role key automatically
- No additional setup needed!
